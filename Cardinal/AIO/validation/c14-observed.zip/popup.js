(() => {
  const $ = id => document.getElementById(id);
  $('version').textContent = `v${chrome.runtime.getManifest().version}`;

  function setStatus(text, kind='') {
    $('status').textContent = text || '';
    $('status').className = `notice ${kind}`;
  }

  function button(label, cls, onClick) {
    const b=document.createElement('button');
    b.className=`btn ${cls}`;
    b.textContent=label;
    b.addEventListener('click',onClick);
    return b;
  }

  async function activeTab() {
    const tabs=await chrome.tabs.query({active:true,currentWindow:true});
    return tabs[0]||null;
  }

  const FORMATIVE_BRIDGE_VERSION='1.1.3';

  async function pingFormative(tabId) {
    try {
      const r=await chrome.tabs.sendMessage(tabId,{type:'CARDINAL_SIMPLE_PING'});
      return !!(r?.ok && r.bridgeVersion===FORMATIVE_BRIDGE_VERSION);
    } catch { return false; }
  }

  async function ensureFormativeUi(tabId) {
    if (await pingFormative(tabId)) return;
    try {
      await chrome.scripting.executeScript({
        target:{tabId},
        files:['formative.js','formative-stealth.js']
      });
      await new Promise(r=>setTimeout(r,160));
      if (!(await pingFormative(tabId))) {
        throw new Error('Le pont Formative ne répond pas après sa réinitialisation.');
      }
    } catch (error) {
      throw new Error('Cardinal a détecté un ancien contexte d’extension dans cet onglet. Recharge complètement Formative puis réessaie.');
    }
  }

  async function sendFormative(tabId, type) {
    await ensureFormativeUi(tabId);
    try { return await chrome.tabs.sendMessage(tabId,{type}); }
    catch { throw new Error('Cardinal n’a pas pu ouvrir cette action dans Formative. Recharge la page puis réessaie.'); }
  }

  async function runStableFormativeAction(tabId, action) {
    try {
      const r=await chrome.runtime.sendMessage({type:'CARDINAL_STABLE_FORMATIVE_ACTION',tabId,action});
      if(!r?.ok) throw new Error(r?.message||'Impossible de préparer Formative.');
      return r;
    } catch(error) {
      throw new Error(error?.message||String(error));
    }
  }

  async function getPendingPreview() {
    try {
      const r=await chrome.runtime.sendMessage({type:'CARDINAL_GET_PENDING_PREVIEW'});
      return r?.ok ? (r.preview || null) : null;
    } catch { return null; }
  }

  function addPendingAction(preview) {
    if (!preview?.context?.formativeId || !Array.isArray(preview?.rows) || !preview.rows.length) return;
    const qs=Array.isArray(preview.context?.questions)?preview.context.questions:[];
    const q=preview.context?.question||qs[0]||{};
    const label=qs.length>1 ? `Reprendre le lot en attente · ${qs.length} questions` : (q.number ? `Reprendre l’envoi en attente · Q${q.number}` : 'Reprendre l’envoi en attente');
    $('actions').append(
      button(label,'primary',async e=>{
        const b=e.currentTarget;b.disabled=true;setStatus('Réouverture du lot en attente…');
        try {
          const r=await chrome.runtime.sendMessage({type:'CARDINAL_RETRY_PENDING_PREVIEW'});
          if(!r?.ok)throw new Error(r?.message||'Impossible de reprendre le lot en attente.');
          window.close();
        } catch(err) { setStatus(err.message||String(err),'err'); b.disabled=false; }
      }),
      button('Abandonner l’envoi en attente','secondary',async e=>{
        const b=e.currentTarget;b.disabled=true;setStatus('Suppression du lot en attente…');
        try {
          const r=await chrome.runtime.sendMessage({type:'CARDINAL_DISCARD_PENDING_PREVIEW'});
          if(!r?.ok)throw new Error(r?.message||'Impossible d’abandonner le lot.');
          setStatus('Envoi en attente abandonné.','ok');
          await render();
        } catch(err) { setStatus(err.message||String(err),'err'); b.disabled=false; }
      })
    );
  }

  async function render() {
    const tab=await activeTab();
    const url=String(tab?.url||'');
    $('actions').innerHTML='';
    const pending=await getPendingPreview();
    addPendingAction(pending);

    if (/^https:\/\/app\.formative\.com\/formatives\/[^/]+\/results/i.test(url)) {
      $('pageTitle').textContent='Formative';
      const u=new URL(url);
      const q=u.searchParams.get('selectedFormativeItemId') || ((u.pathname.match(/\/results\/([^/?#]+)/i)||[])[1]||'');
      $('pageMeta').textContent = q ? 'Une question est actuellement sélectionnée.' : 'Ouvre la question que tu veux corriger, ou choisis-la après.';
      $('actions').append(
        button('Préparer une correction',pending?'secondary':'primary',async e=>{
          const b=e.currentTarget;b.disabled=true;setStatus('Préparation de Formative… Si une actualisation est nécessaire, Cardinal reprendra automatiquement.');
          try{
            const r=await runStableFormativeAction(tab.id,'correction');
            if(r?.ok===false)throw new Error(r.message||'Impossible d’ouvrir la correction.');
            window.close();
          }catch(err){setStatus(err.message||String(err),'err');b.disabled=false;}
        }),
        button('Envoyer le résultat global dans Gestion','secondary',async e=>{
          const b=e.currentTarget;b.disabled=true;setStatus('Préparation du résultat global…');
          try{
            const r=await runStableFormativeAction(tab.id,'global');
            if(r?.ok===false)throw new Error(r.message||'Impossible de préparer le résultat global.');
            window.close();
          }catch(err){setStatus(err.message||String(err),'err');b.disabled=false;}
        })
      );
      setStatus('Formative reste complètement inchangé tant que tu n’ouvres pas une action Cardinal.','ok');
      return;
    }

    if (/^https:\/\/techno-cardi\.github\.io\/Exercices-francais\/resultats/i.test(url)) {
      $('pageTitle').textContent='Gestion des notes';
      $('pageMeta').textContent='La synchronisation Mozaïk et les imports Formative sont disponibles directement dans la plateforme.';
      setStatus('La détection des groupes et des listes Mozaïk s’effectue automatiquement au moment de la synchronisation.','ok');
      return;
    }

    if (/^https:\/\/mozaikportail\.ca\//i.test(url)) {
      $('pageTitle').textContent='Mozaïk';
      $('pageMeta').textContent='Cardinal observe les groupes, matières et listes officielles chargés par le portail pour garder la configuration à jour.';
      setStatus('Aucun bouton supplémentaire n’est ajouté à la page.','ok');
      return;
    }

    if (/^https:\/\/(chatgpt\.com|chat\.openai\.com)\//i.test(url)) {
      $('pageTitle').textContent='Correction';
      $('pageMeta').textContent='Cardinal détecte automatiquement les tableaux de notes ou de commentaires, y compris les lots de plusieurs questions.';
      setStatus('Si un tableau compatible est détecté dans la dernière réponse, le bouton d’envoi vers Formative apparaît directement dans ChatGPT.','ok');
      return;
    }

    $('pageTitle').textContent='Cardinal';
    $('pageMeta').textContent='Ouvre Formative, Gestion des notes ou Mozaïk pour utiliser les fonctions automatiques.';
    setStatus('');
  }

  render().catch(e=>setStatus(e?.message||String(e),'err'));
})();
