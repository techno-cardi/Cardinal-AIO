(() => {
  const PAGE_SOURCE = 'cardinal-mozaik-console';
  const EXT_SOURCE = 'cardinal-mozaik-extension';
  const FORMATIVE_PAGE_SOURCE = 'cardinal-formative-console';
  const FORMATIVE_EXT_SOURCE = 'cardinal-formative-extension';
  let pendingFormativeImport = null;
  let pendingFormativeImportNonce = 0;
  let postedFormativeImportNonce = -1;
  let pendingFormativeFeedback = null;

  function clearPendingFormativeImport() {
    pendingFormativeImport = null;
    postedFormativeImportNonce = pendingFormativeImportNonce;
    // Gestion des notes garde aussi son propre marqueur dans sessionStorage.
    // Il faut le retirer lorsqu'on annule, sinon son intervalle rouvre le dialogue.
    try {
      sessionStorage.removeItem('pending_formative_import');
      sessionStorage.removeItem('cardinal_global_formative_import');
    } catch {}
  }

  function postPendingFormativeImport() {
    if (!pendingFormativeImport || postedFormativeImportNonce === pendingFormativeImportNonce) return;
    postedFormativeImportNonce = pendingFormativeImportNonce;
    window.postMessage({ source: FORMATIVE_EXT_SOURCE, type: 'FORMATIVE_IMPORT_AVAILABLE', payload: pendingFormativeImport }, location.origin);
  }

  function postPendingFormativeFeedback() {
    if (!pendingFormativeFeedback) return;
    window.postMessage({ source: FORMATIVE_EXT_SOURCE, type: 'FORMATIVE_CHATGPT_FEEDBACK_AVAILABLE', payload: pendingFormativeFeedback }, location.origin);
  }

  function announceReady() {
    window.postMessage({
      source: EXT_SOURCE,
      type: 'MOZAIK_EXTENSION_READY',
      version: chrome.runtime.getManifest().version
    }, location.origin);
    window.postMessage({
      source: FORMATIVE_EXT_SOURCE,
      type: 'FORMATIVE_EXTENSION_READY',
      version: chrome.runtime.getManifest().version
    }, location.origin);
  }

  document.addEventListener('click', event => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;

    // Fermer/annuler l'import doit être définitif pour CE lot.
    // Sans ceci, Gestion conserve pending_formative_import et rouvre le dialogue toutes les 1,2 s.
    if (target.closest('#closeFormativeDialog,#cancelFormativeImport')) {
      clearPendingFormativeImport();
      return;
    }

    const btn = target.closest('#syncMozaikBtn');
    if (!btn || btn.disabled) return;
    chrome.runtime.sendMessage({ type: 'SHOW_MOZAIK_SYNC_UI' }).catch(() => {});
  }, true);

  // Couvre aussi la fermeture native du <dialog> avec Échap.
  document.addEventListener('cancel', event => {
    if (event.target instanceof Element && event.target.id === 'formativeImportDialog') clearPendingFormativeImport();
  }, true);

  function enableEnterLogin() {
    document.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' || event.defaultPrevented) return;
      const target = event.target;
      if (!(target instanceof HTMLInputElement)) return;
      if ((target.id === 'email' || target.id === 'password') && document.getElementById('loginBtn')) {
        event.preventDefault();
        document.getElementById('loginBtn').click();
        return;
      }
      if ((target.id === 'newPassword' || target.id === 'confirmPassword') && document.getElementById('activateBtn')) {
        event.preventDefault();
        document.getElementById('activateBtn').click();
      }
    });
  }

  announceReady();
  enableEnterLogin();
  window.addEventListener('load', () => { setTimeout(postPendingFormativeImport, 250); setTimeout(postPendingFormativeFeedback, 300); });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'FORMATIVE_IMPORT_AVAILABLE') {
      pendingFormativeImport = message.payload || null;
      pendingFormativeImportNonce += 1;
      postedFormativeImportNonce = -1;
      postPendingFormativeImport();
      sendResponse?.({ ok: true });
      return;
    }
    if (message?.type === 'FORMATIVE_CHATGPT_FEEDBACK_AVAILABLE') {
      pendingFormativeFeedback = message.payload || null;
      postPendingFormativeFeedback();
      setTimeout(postPendingFormativeFeedback, 500);
      setTimeout(postPendingFormativeFeedback, 1500);
      sendResponse?.({ ok: true });
    }
  });

  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const data = event.data;
    if (!data) return;

    if (data.source === FORMATIVE_PAGE_SOURCE) {
      if (data.type === 'FORMATIVE_EXTENSION_PING') {
        announceReady();
        postPendingFormativeImport();
        postPendingFormativeFeedback();
        return;
      }
      if (data.type !== 'FORMATIVE_EXTENSION_REQUEST') return;
      const requestId = String(data.requestId || '');
      if (!requestId) return;
      try {
        const result = await chrome.runtime.sendMessage({
          type: 'FORMATIVE_REQUEST',
          action: data.action,
          payload: data.payload || {}
        });
        window.postMessage({ source: FORMATIVE_EXT_SOURCE, type: 'FORMATIVE_EXTENSION_RESULT', requestId, result }, location.origin);
      } catch (error) {
        window.postMessage({
          source: FORMATIVE_EXT_SOURCE,
          type: 'FORMATIVE_EXTENSION_RESULT',
          requestId,
          result: { ok: false, message: error?.message || String(error) }
        }, location.origin);
      }
      return;
    }

    if (data.source !== PAGE_SOURCE) return;
    if (data.type === 'MOZAIK_EXTENSION_PING') {
      announceReady();
      return;
    }
    if (data.type === 'MOZAIK_EXTENSION_SHOW_PROGRESS') {
      try { await chrome.runtime.sendMessage({ type: 'SHOW_MOZAIK_SYNC_UI' }); } catch {}
      return;
    }
    if (data.type === 'MOZAIK_EXTENSION_PROGRESS') {
      try {
        await chrome.runtime.sendMessage({
          type: 'UPDATE_MOZAIK_SYNC_UI',
          payload: data.payload || {}
        });
      } catch {}
      return;
    }
    if (data.type === 'MOZAIK_EXTENSION_DISCOVER_GROUP') {
      const requestId = String(data.requestId || '');
      if (!requestId) return;
      try {
        const result = await chrome.runtime.sendMessage({ type:'DISCOVER_MOZAIK_GROUP', groupCode:String(data.groupCode || ''), force:data.force === true });
        window.postMessage({ source:EXT_SOURCE, type:'MOZAIK_EXTENSION_DISCOVERY_RESULT', requestId, result }, location.origin);
      } catch (error) {
        window.postMessage({ source:EXT_SOURCE, type:'MOZAIK_EXTENSION_DISCOVERY_RESULT', requestId, result:{ok:false,message:error?.message||String(error)} }, location.origin);
      }
      return;
    }
    if (data.type !== 'MOZAIK_EXTENSION_SYNC') return;
    const requestId = String(data.requestId || '');
    if (!requestId) return;
    try {
      const response = await chrome.runtime.sendMessage({ type: 'START_MOZAIK_SYNC', requestId, payload: data.payload });
      window.postMessage({
        source: EXT_SOURCE,
        type: 'MOZAIK_EXTENSION_RESULT',
        requestId,
        result: response || { success: false, message: 'Aucune réponse de l’extension.' }
      }, location.origin);
    } catch (error) {
      window.postMessage({
        source: EXT_SOURCE,
        type: 'MOZAIK_EXTENSION_RESULT',
        requestId,
        result: { success: false, message: error?.message || String(error) }
      }, location.origin);
    }
  });
})();

(() => {
  if (window.__cardinalMozaikDiscoveryBridge094) return;
  window.__cardinalMozaikDiscoveryBridge094 = true;
  const PAGE_SOURCE = 'cardinal-mozaik-console';
  const EXT_SOURCE = 'cardinal-mozaik-extension';

  window.addEventListener('message', async event => {
    if (event.source !== window || event.origin !== location.origin) return;
    const data = event.data;
    if (data?.source !== PAGE_SOURCE || data?.type !== 'MOZAIK_EXTENSION_DISCOVER_GROUP_V3') return;
    const requestId = String(data.requestId || '');
    if (!requestId) return;
    try {
      const code = String(data.groupCode || '');
      const fallback = data.fallbackGroup && typeof data.fallbackGroup === 'object' ? data.fallbackGroup : null;
      const currentYearStart = (() => { const d = new Date(); return d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1; })();
      const fallbackYear = (() => {
        if (!fallback) return 0;
        const establishment = String(fallback.establishmentId || '');
        const id = String(fallback.groupMatterId || fallback.groupCourseId || '');
        if (!establishment || !id.startsWith(establishment)) return 0;
        const m = id.slice(establishment.length).match(/^(20\d{2})/);
        return m ? Number(m[1]) : 0;
      })();
      const storedMappingIsCurrent = !!fallback && fallbackYear === currentYearStart
        && String(fallback.groupCourseId || '').endsWith(`-${code}`)
        && String(fallback.groupMatterId || '').endsWith(`-${code}`);

      // Normal daily sync: the mapping was already validated for this school year.
      // Let Gestion re-confirm the stored mapping server-side without opening/navigating Mozaïk.
      // A new school year or a forced refresh still runs full live discovery.
      if (storedMappingIsCurrent && data.force !== true) {
        const result = { ok:true, group:{...fallback, code}, roster:[], source:'stored-current-year' };
        window.postMessage({ source:EXT_SOURCE, type:'MOZAIK_EXTENSION_DISCOVERY_RESULT_V3', requestId, result }, location.origin);
        return;
      }

      const result = await chrome.runtime.sendMessage({
        type:'DISCOVER_MOZAIK_GROUP_V3',
        groupCode:code,
        force:data.force === true,
        fallbackGroup:fallback
      });
      window.postMessage({ source:EXT_SOURCE, type:'MOZAIK_EXTENSION_DISCOVERY_RESULT_V3', requestId, result }, location.origin);
    } catch (error) {
      window.postMessage({
        source:EXT_SOURCE,
        type:'MOZAIK_EXTENSION_DISCOVERY_RESULT_V3',
        requestId,
        result:{ ok:false, message:error?.message || String(error) }
      }, location.origin);
    }
  });
})();
