'use strict';
importScripts('diagnostics.js');
try { importScripts('legacy-service-worker.js'); globalThis.CardinalDiagnostics?.record?.('service-worker','module.loaded',{modulePath:'legacy-service-worker.js'}); }
catch (error) { globalThis.CardinalDiagnostics?.record?.('service-worker','module.load.error',{modulePath:'legacy-service-worker.js',name:error?.name||null,message:error?.message||String(error),stack:String(error?.stack||'').slice(0,3000)},'error'); }
try { importScripts('classroom-background-aio.js'); globalThis.CardinalDiagnostics?.record?.('service-worker','module.loaded',{modulePath:'classroom-background-aio.js'}); }
catch (error) { globalThis.CardinalDiagnostics?.record?.('service-worker','module.load.error',{modulePath:'classroom-background-aio.js',name:error?.name||null,message:error?.message||String(error),stack:String(error?.stack||'').slice(0,3000)},'error'); }
try { importScripts('background-v2.js'); globalThis.CardinalDiagnostics?.record?.('service-worker','module.loaded',{modulePath:'background-v2.js'}); }
catch (error) { globalThis.CardinalDiagnostics?.record?.('service-worker','module.load.error',{modulePath:'background-v2.js',name:error?.name||null,message:error?.message||String(error),stack:String(error?.stack||'').slice(0,3000)},'error'); }
