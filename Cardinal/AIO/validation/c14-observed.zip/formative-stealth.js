(() => {
  const INSTANCE_TOKEN = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  window.__cardinalFormativeStealthActiveToken = INSTANCE_TOKEN;

  function scrubText(root) {
    try {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        const before = String(node.nodeValue || '');
        if (/chatgpt/i.test(before)) {
          const after = before.replace(/ChatGPT/gi, 'assistant de correction');
          if (after !== before) node.nodeValue = after;
        }
      }
    } catch {}
  }

  function sanitize() {
    const host = document.getElementById('cardinal-formative-simple-092');
    const root = host?.shadowRoot;
    if (!root) return null;

    const launcher = root.querySelector('.launcher');
    if (launcher && launcher.style.display !== 'none') {
      launcher.style.setProperty('display', 'none', 'important');
    }

    const copy = root.getElementById('copyOpenBtn');
    if (copy && copy.textContent !== 'Copier les réponses') {
      copy.textContent = 'Copier les réponses';
    }

    const previewEyebrow = root.querySelector('#previewModal .eyebrow');
    if (previewEyebrow && previewEyebrow.textContent !== 'Retour de correction') {
      previewEyebrow.textContent = 'Retour de correction';
    }

    scrubText(root);
    return root;
  }

  // Important: aucun MutationObserver ici. La v0.9.3 observait le DOM puis
  // réécrivait textContent dans son propre callback, ce qui pouvait créer une
  // boucle de mutations et figer l'onglet Formative.
  let attempts = 0;
  function prepare() {
    if (sanitize()) return;
    if (++attempts < 20) setTimeout(prepare, 50);
  }
  prepare();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (window.__cardinalFormativeStealthActiveToken !== INSTANCE_TOKEN) return;
    if (message?.type !== 'CARDINAL_SIMPLE_OPEN_CORRECTION' && message?.type !== 'CARDINAL_SIMPLE_SEND_GLOBAL') return;
    const root = sanitize();
    if (!root) {
      sendResponse({ ok:false, message:'Interface Cardinal non prête. Réessaie dans un instant.' });
      return;
    }
    const id = message.type === 'CARDINAL_SIMPLE_OPEN_CORRECTION' ? 'correctBtn' : 'gestionBtn';
    const btn = root.getElementById(id);
    if (!btn) {
      sendResponse({ ok:false, message:'Action Cardinal introuvable.' });
      return;
    }
    btn.click();
    sendResponse({ ok:true });
  });
})();
