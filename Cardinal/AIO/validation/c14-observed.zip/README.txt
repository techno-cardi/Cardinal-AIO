Cardinal - Gestion des notes v1.1.8

Nouveauté 1.1.8 :
- Chaque tableau ChatGPT compatible « Élève | Note | Commentaire » ou « Élève | Commentaire » reçoit sa propre barre Cardinal directement sous le tableau.
- La barre reste disponible même si plusieurs nouveaux messages sont ajoutés ensuite à la conversation.
- Le bouton relit uniquement le tableau auquel il est attaché au moment du clic; il ne dépend plus de la dernière réponse ChatGPT.
- La question et l’identifiant de lot sont recherchés dans le voisinage local de ce tableau, pas dans la fin actuelle de la conversation.
- Si un ancien tableau appartient explicitement à un autre lot actif, l’envoi est bloqué plutôt que redirigé silencieusement.
- Les tableaux de commentaires partiels de 1.1.7 restent pris en charge.
- Le bouton flottant historique est conservé seulement comme solution de repli; lorsqu’une barre locale est présente sous le dernier tableau, il est masqué pour éviter les doublons.
- Les barres sont recréées automatiquement si ChatGPT rerend le DOM grâce à un MutationObserver, selon le même principe que l’importateur de questions Formative.

INSTALLATION / MISE À JOUR 1.1.8
1. Remplace le contenu du dossier actuel de l’extension par celui de 1.1.8.
2. Dans chrome://extensions, clique « Recharger » sur Cardinal - Gestion des notes.
3. Recharge l’onglet ChatGPT une fois pour injecter le nouveau pont 1.1.8.
4. Les anciens tableaux compatibles déjà visibles dans la conversation recevront automatiquement leur barre Cardinal.

Cardinal - Gestion des notes v1.1.7

Correctif 1.1.7 :
- Autorise un retour ChatGPT volontairement partiel lorsqu’il contient uniquement des commentaires pour certains élèves.
- Si CARDINAL_BATCH_ID est invisible dans le DOM, la récupération partielle n’est permise que si chaque ligne correspond à un élève/question du lot Formative actif; une ligne étrangère, ambiguë ou invalide bloque toujours l’envoi.
- Les tableaux contenant des notes conservent l’exigence de complétude du lot.
- Le tampon Formative ne considère plus les élèves volontairement omis comme des résultats manquants lorsqu’aucune note n’est envoyée.
- Le prompt Cardinal précise qu’un suivi « seulement certains élèves, aucun retour aux autres » doit rester partiel plutôt que recréer des lignes vides.
- Le pont ChatGPT est versionné 1.1.7 afin d’éviter qu’un ancien pont survive à la mise à jour.


INSTALLATION / MISE À JOUR 1.1.7
1. Dans chrome://extensions, repère « Cardinal - Gestion des notes ».
2. Ne laisse jamais deux versions de Cardinal - Gestion des notes actives en même temps.
3. Méthode recommandée : remplace le contenu de ton dossier d’extension actuel par celui de 1.1.7, puis clique « Recharger » sur la carte de l’extension.
4. Si tu préfères charger un nouveau dossier avec « Charger l’extension non empaquetée », désactive ou supprime d’abord l’ancienne version.
5. Recharge complètement les onglets Gestion des notes ET Mozaïk après la mise à jour.
6. Vérifie dans le popup Cardinal qu’il affiche v1.1.7.

Cardinal - Gestion des notes v1.1.4

Cette version part directement de v1.0.2 stable et ajoute le traitement par lots sans retirer les sécurités existantes.

Correctif 1.1.3 :
- Répare la liaison de lot ChatGPT/Formative lorsque les gros collages sont transformés en pièce jointe et que CARDINAL_BATCH_ID n’est plus visible dans le DOM.
- Ajoute un identifiant de lot stable pour une même évaluation, classe, mode et sélection de questions, même après fermeture/réouverture de Formative.
- Demande à ChatGPT de recopier CARDINAL_BATCH_ID juste avant le tableau final pour rendre les prochains lots auto-identifiables.
- Ajoute une récupération sécurisée par correspondance structurelle exacte (questions + élèves) avant le tampon de prévisualisation si l’identifiant n’est pas lisible.
- Le bouton manuel « Envoyer ce texte » utilise maintenant la même récupération au lieu d’être bloqué par la même erreur.
- Met à jour les ponts internes à 1.1.3 pour qu’une réinjection après mise à jour charge réellement le nouveau code.

Correctif 1.1.2 :
- les séparateurs artificiels « | » ne sont plus insérés entre les paragraphes ou fragments d’une réponse;
- les fragments de texte continu sont réunis avec un espace, tandis que les rares valeurs multiples d’un même champ structuré utilisent « ; » pour rester lisibles.

Correctif 1.1.1 :
- le décodeur ignore maintenant les métadonnées de mise en forme ProseMirror (attrs, dir=auto, textAlign, etc.) au lieu de les mélanger au texte des élèves;
- le mot « auto » reste conservé s’il fait réellement partie de la réponse de l’élève.

Nouveautés 1.1.0 :
- Commentaires seulement : dans « Préparer une correction », coche « Commentaires seulement ». ChatGPT peut retourner « Élève | Commentaire » sans aucune note.
- Détection automatique d’un tableau de commentaires seulement même si le lot avait été préparé en mode normal.
- Plusieurs questions : coche « Plusieurs questions », sélectionne les questions, puis Cardinal copie un seul prompt dans ChatGPT.
- Format multi-questions : « Question | Élève | Note | Commentaire » ou, en commentaires seulement, « Question | Élève | Commentaire ».
- Un seul bouton ChatGPT prépare tout le lot et ouvre une seule prévisualisation dans Formative.
- Tampon Cardinal persistant : aucun résultat n’est écrit avant la prévisualisation et le clic final « Publier dans Formative ».
- Liaison de sécurité par CARDINAL_BATCH_ID : le tableau ChatGPT doit provenir du lot actuellement préparé.
- En multi-questions, chaque ligne est liée explicitement à Qn et toute question sélectionnée absente du retour bloque la publication.
- Préflight complet de toutes les questions avant la première écriture.
- Les notes sont écrites par question et par valeur, puis relues directement sur le serveur Formative.
- Les commentaires sont dédupliqués et le ledger permet de reprendre un lot partiellement écrit sans recopier ce qui est déjà confirmé.
- Les questions avec grille structurée restent protégées : notes automatiques bloquées, commentaires autorisés.

Sécurités conservées :
- aucune MutationObserver réécrivant le DOM Formative;
- empreinte des réponses avant publication;
- blocage si une réponse a changé, sauf confirmation explicite;
- détection des réponses identiques notées différemment;
- vérification Q/tableau et maintenant lot/session;
- reprise après rechargement de l’extension;
- aperçu obligatoire avant publication.

Test de promotion recommandé avant de remplacer 1.0.2 comme stable :
1. Q unique, commentaires seulement, 2 ou 3 élèves.
2. Deux questions, commentaires seulement, publication en un seul lot.
3. Deux questions avec notes, dont des maximums différents, publication en un seul lot.
4. Fermer la prévisualisation puis « Reprendre le lot en attente ».
5. Vérifier que la relecture serveur confirme les notes.

Garde le ZIP v1.0.2 comme rollback jusqu’à ce que ces tests soient passés dans ton vrai Formative.

Révision pré-installation :
- le tampon de cohérence ignore maintenant complètement les lignes sans note, donc un lot « commentaires seulement » ne peut pas être bloqué à tort comme si une note 0 avait été proposée;
- l’empreinte de sécurité porte sur le contenu structuré complet de la réponse, pas seulement sur le texte aplati, afin de détecter aussi une modification d’une réponse à trous, d’un QCM ou d’un autre format structuré;
- le prompt multi-question impose une présentation lisible par question puis un seul tableau importable final;
- le bouton ChatGPT indique le nombre exact de lignes qui seront placées dans le tampon avant l’ouverture de Formative.
- le tampon bloque maintenant toute publication si une ligne est non reconnue, ambiguë ou invalide, ou si le tableau final oublie une réponse qui avait été envoyée à ChatGPT; aucun lot multi-question tronqué ne peut donc partir silencieusement.

Nouveauté - commentaires plus naturels :
- le prompt Cardinal impose maintenant un ton de prof de français du secondaire au Québec : naturel, direct, professionnel, généralement 1 à 3 phrases;
- débuts variés possibles (« Salut », « Wow, c’est très bien », « C’est bon », prénom occasionnel), sans emojis et sans formulations répétitives;
- quand un élève cite un texte, Cardinal demande des guillemets français « ... » et, si le texte est numéroté, rappelle naturellement à l’élève d’indiquer la ou les lignes de son extrait; aucun numéro de ligne/page n’est inventé et ce rappel ne retire pas automatiquement des points sauf si la consigne ou le barème l’exige;
- quand Formative expose les rétroactions précédentes liées à une réponse, Cardinal les transmet à ChatGPT pour tenir compte d’un échange déjà amorcé;
- l’historique est limité aux 4 derniers messages liés à la réponse pour garder le prompt lisible;
- si Formative refuse temporairement la lecture de l’historique, la préparation continue sans l’inventer : les notes/réponses restent utilisables, mais ChatGPT n’est pas autorisé à prétendre qu’un échange antérieur a eu lieu.


=== Version 1.1.4 ===
- Mozaïk passe immédiatement au premier plan dès le lancement d’une synchronisation.
- Le panneau de progression ne disparaît plus lorsqu’on clique dans la page.
- Fermer le panneau ne ferme plus l’onglet Mozaïk.
- Un succès est refusé si l’identifiant d’activité manque ou si le nombre de notes confirmé ne correspond pas au lot envoyé.
- Tous les correctifs Formative/ChatGPT de la 1.1.3 sont conservés.


Version 1.1.6
- Supprime l’attente artificielle de 120-180 secondes liée à window.authentification.AccessToken.
- Capture le jeton Bearer déjà utilisé par les requêtes officielles de Mozaïk via webRequest, en mémoire/session uniquement.
- Valide rapidement la session avant l’envoi.
- Si l’extension vient d’être mise à jour et n’a encore capturé aucun jeton, recharge Mozaïk une seule fois pour récupérer la session au lieu d’attendre plusieurs minutes.
- Injecte et affiche la barre de progression dès le premier clic, même si l’onglet Mozaïk doit finir de charger.
- Conserve les correctifs Formative/ChatGPT de la 1.1.4.
