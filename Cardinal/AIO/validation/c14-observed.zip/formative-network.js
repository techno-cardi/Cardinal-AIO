(() => {
  if (window.__cardinalFormativeNetworkCaptureInstalled) return;
  window.__cardinalFormativeNetworkCaptureInstalled = true;

  const CACHE_KEY = '__cardinalFormativeGraphqlCache';
  const MAX_RECORDS = 24;
  const cache = window[CACHE_KEY] = Array.isArray(window[CACHE_KEY]) ? window[CACHE_KEY] : [];

  function keepRecord(record) {
    try {
      const query = String(record?.query || '');
      const op = String(record?.operationName || '');
      if (!/(formative|answer|question|item|result|response|choice|option|blank|matching)/i.test(`${op} ${query}`)) return;
      if (record?.data === undefined || record?.data === null) return;
      cache.push({
        ts: Date.now(),
        operationName: op,
        variables: record?.variables || {},
        query,
        data: record?.data ?? null
      });
      if (cache.length > MAX_RECORDS) cache.splice(0, cache.length - MAX_RECORDS);
    } catch {}
  }

  function parseBody(body) {
    if (!body) return null;
    if (typeof body === 'string') {
      try { return JSON.parse(body); } catch { return null; }
    }
    return null;
  }

  function isGraphqlUrl(url) {
    return /^https:\/\/svc\.goformative\.com\/graphql(?:\/|\?|$)/i.test(String(url || ''));
  }

  function keepPayload(body, json) {
    try {
      const ops = Array.isArray(body) ? body : [body];
      const outs = Array.isArray(json) ? json : [json];
      ops.forEach((op, i) => {
        if (!op || typeof op !== 'object') return;
        const out = outs[i] || outs[0] || {};
        keepRecord({
          operationName: op.operationName,
          variables: op.variables,
          query: op.query,
          data: out?.data
        });
      });
    } catch {}
  }

  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = async function(input, init) {
      const response = await originalFetch.apply(this, arguments);
      try {
        const url = typeof input === 'string' ? input : (input?.url || '');
        if (isGraphqlUrl(url)) {
          let body = parseBody(init?.body);
          if (!body && input instanceof Request) {
            try { body = parseBody(await input.clone().text()); } catch {}
          }
          if (body) response.clone().json().then(json => keepPayload(body, json)).catch(() => {});
        }
      } catch {}
      return response;
    };
  }

  const XHR = window.XMLHttpRequest;
  if (XHR?.prototype) {
    const originalOpen = XHR.prototype.open;
    const originalSend = XHR.prototype.send;
    XHR.prototype.open = function(method, url) {
      try { this.__cardinalGraphqlUrl = isGraphqlUrl(url) ? String(url) : ''; } catch {}
      return originalOpen.apply(this, arguments);
    };
    XHR.prototype.send = function(body) {
      try {
        const parsed = this.__cardinalGraphqlUrl ? parseBody(body) : null;
        if (parsed) {
          this.addEventListener('load', () => {
            try { keepPayload(parsed, JSON.parse(this.responseText || '{}')); } catch {}
          }, { once:true });
        }
      } catch {}
      return originalSend.apply(this, arguments);
    };
  }
})();
